## Where is the connections config stored?
**Windows** `C:\Users\%Your user%\.rdm\connections.json`

**OS X** `$HOME/Library/Preferences/rdm/connections.json`

**Linux** `$HOME/.rdm/connections.json`
