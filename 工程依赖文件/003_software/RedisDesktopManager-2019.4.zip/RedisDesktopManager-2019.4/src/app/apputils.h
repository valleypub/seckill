#pragma once
#include <QString>

QString humanReadableSize(long size);
