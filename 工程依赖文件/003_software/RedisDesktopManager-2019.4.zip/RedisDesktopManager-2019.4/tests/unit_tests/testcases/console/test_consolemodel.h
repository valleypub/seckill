#pragma once
#include "basetestcase.h"

class TestConsoleOperations : public BaseTestCase
{
	Q_OBJECT

private slots:
	void init_invalid();
};
